﻿local effect = {}

effect.name = "MaxHelpingHand/SnowCustomColors"
effect.canBackground = true
effect.canForeground = true

effect.defaultData = {
    colors = "FF0000,00FF00,0000FF",
    speedMin = 40.0,
    speedMax = 100.0
}

return effect
