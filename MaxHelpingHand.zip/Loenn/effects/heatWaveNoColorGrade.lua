﻿local effect = {}

effect.name = "MaxHelpingHand/HeatWaveNoColorGrade"
effect.canBackground = true
effect.canForeground = true

effect.defaultData = {
    controlColorGradeWhenActive = false,
    renderParticles = true
}

return effect
