local trigger = {}

trigger.name = "MaxHelpingHand/MadelinePonytailTrigger"
trigger.placements = {
    name = "trigger",
    data = {
        enable = true
    }
}

return trigger