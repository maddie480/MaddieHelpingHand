local trigger = {}

trigger.name = "MaxHelpingHand/OneWayCameraTrigger"
trigger.placements = {
    name = "trigger",
    data = {
        left = true,
        right = true,
        up = true,
        down = true,
        flag = "",
        blockPlayer = false
    }
}

return trigger