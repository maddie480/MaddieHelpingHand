local trigger = {}

trigger.name = "MaxHelpingHand/GradientDustTrigger"
trigger.placements = {
    name = "trigger",
    data = {
        gradientImage = "MaxHelpingHand/gradientdustbunnies/bluegreen",
        scrollSpeed = 50.0
    }
}

return trigger