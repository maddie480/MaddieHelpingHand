local trigger = {}

trigger.name = "MaxHelpingHand/SetDarknessAlphaTrigger"
trigger.placements = {
    name = "trigger",
    data = {
        value = 0.0
    }
}

return trigger