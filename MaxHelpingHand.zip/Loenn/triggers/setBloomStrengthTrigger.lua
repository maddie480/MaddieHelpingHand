local trigger = {}

trigger.name = "MaxHelpingHand/SetBloomStrengthTrigger"
trigger.placements = {
    name = "trigger",
    data = {
        value = 1.0
    }
}

return trigger