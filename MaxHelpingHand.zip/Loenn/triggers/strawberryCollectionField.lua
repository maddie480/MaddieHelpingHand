local trigger = {}

trigger.name = "MaxHelpingHand/StrawberryCollectionField"
trigger.placements = {
    name = "trigger",
    data = {
        delayBetweenBerries = true,
        includeGoldens = false
    }
}

return trigger