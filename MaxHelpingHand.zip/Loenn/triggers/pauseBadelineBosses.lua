local trigger = {}

trigger.name = "MaxHelpingHand/PauseBadelineBossesTrigger"
trigger.placements = {
    name = "trigger"
}

return trigger