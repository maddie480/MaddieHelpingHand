local trigger = {}

trigger.name = "MaxHelpingHand/DisableIcePhysicsTrigger"
trigger.placements = {
    name = "trigger",
    data = {
        disableIcePhysics = true
    }
}

return trigger