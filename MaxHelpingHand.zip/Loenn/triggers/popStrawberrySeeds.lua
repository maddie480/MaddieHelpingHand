local trigger = {}

trigger.name = "MaxHelpingHand/PopStrawberrySeedsTrigger"
trigger.placements = {
    name = "trigger"
}

return trigger