local trigger = {}

trigger.name = "MaxHelpingHand/ActivateTimedTouchSwitchesTimerTrigger"
trigger.placements = {
    name = "trigger"
}

return trigger