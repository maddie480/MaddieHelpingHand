﻿local lavaBlocker = {}

lavaBlocker.name = "MaxHelpingHand/InstantLavaBlockerTrigger"
lavaBlocker.placements = {
    name = "lava_blocker",
    data = {
        canReenter = false
    }
}

return lavaBlocker
