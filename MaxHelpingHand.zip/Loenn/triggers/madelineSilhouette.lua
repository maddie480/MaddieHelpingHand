local trigger = {}

trigger.name = "MaxHelpingHand/MadelineSilhouetteTrigger"
trigger.placements = {
    name = "trigger",
    data = {
        enable = true
    }
}

return trigger