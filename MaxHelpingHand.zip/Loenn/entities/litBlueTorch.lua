local torch = {}

torch.name = "MaxHelpingHand/LitBlueTorch"
torch.depth = 2000
torch.placements = {
    name = "torch"
}

torch.texture = "objects/temple/torch03"

return torch
