local parallaxController = {}

parallaxController.name = "MaxHelpingHand/ParallaxFadeOutController"
parallaxController.depth = 0
parallaxController.texture = "@Internal@/northern_lights"
parallaxController.placements = {
    name = "controller"
}

return parallaxController
