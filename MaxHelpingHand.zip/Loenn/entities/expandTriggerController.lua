local controller = {}

controller.name = "MaxHelpingHand/ExpandTriggerController"
controller.depth = 0
controller.texture = "ahorn/MaxHelpingHand/expand_trigger_controller"
controller.placements = {
    name = "controller"
}

return controller
