local colorController = {}

colorController.name = "MaxHelpingHand/RainbowSpinnerColorControllerDisabler"
colorController.depth = 0
colorController.texture = "ahorn/MaxHelpingHand/rainbowSpinnerColorControllerDisable"
colorController.placements = {
    name = "controller"
}

return colorController
