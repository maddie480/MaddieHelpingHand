local horizontalRoomWrapController = {}

horizontalRoomWrapController.name = "MaxHelpingHand/HorizontalRoomWrapController"
horizontalRoomWrapController.depth = 0
horizontalRoomWrapController.placements = {
    name = "controller"
}

horizontalRoomWrapController.texture = "ahorn/MaxHelpingHand/horizontal_room_wrap"

return horizontalRoomWrapController
