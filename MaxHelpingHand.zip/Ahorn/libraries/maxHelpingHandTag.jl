﻿module MaxHelpingHand
# *waves at Communal Helper*
end